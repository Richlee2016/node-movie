"use strict";

const Controller = require("egg").Controller;
class MoviesController extends Controller {
  constructor(app) {
    super(app);
  }
  
  async search(ctx){
    const {wd} = ctx.query;
    const res = await ctx.service.crawler.proxyOnlineSearch(wd); 
    ctx.body = res;
  }

}

module.exports = MoviesController;
