module.exports = {
  qiniu: {
    cname: "http://go.richfly.cn/",
    bucket: "eggapi",
    AK: "OBDA2gN9-FJfAzWExCHGNNG9QW5FqNtUrD57IwIi",
    SK: "lkrOjtgXY4WmN7NcJNSKNXb7aLue13_CPg_0X0NH"
  }
};
